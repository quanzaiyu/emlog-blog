<?php
    $Liang_zsshare_config = array(
	"zfbskr" => "731734107@qq.com",
	"zfbpr" => "http://www.xiaoyulive.top/content/plugins/Liang_zsshare/card.png",
	"wxpr" => "http://www.xiaoyulive.top/content/plugins/Liang_zsshare/weixinpay.png",
);